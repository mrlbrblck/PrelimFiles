import javax.swing.*;

public class Babababa {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginSignUpSelectionFrame::new);
    }
    
}
